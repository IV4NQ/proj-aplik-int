alert("Dodawanie")
let skladnik1 = parseInt(prompt("Podaj pierwszą liczbę:"," 0"));
let skladnik2 = parseInt(prompt("Podaj drugą liczbę:" , "0"));


let wynik = skladnik1 + skladnik2;

document.write(skladnik1 + "+" + skladnik2 + "=" + wynik);