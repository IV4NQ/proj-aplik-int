alert("Witaj na mojej stronie")
let imie = prompt("Podaj swoje imię"," Anonim")
document.write("Cześć" + imie);