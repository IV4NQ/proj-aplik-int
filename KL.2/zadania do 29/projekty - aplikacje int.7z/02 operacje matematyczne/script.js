
let skladnik1 = parseInt(prompt("Podaj pierwszą liczbę:"," 0"));
let skladnik2 = parseInt(prompt("Podaj drugą liczbę:" , "0"));

let wynik1 = skladnik1 + skladnik2;
document.write(skladnik1 + "+" + skladnik2 + "=" + wynik1);
let wynik2 = skladnik1 / skladnik2;
document.write(skladnik1 + "/" + skladnik2 + "=" + wynik2);
let wynik2 = skladnik1 - skladnik2;
document.write(skladnik1 + "-" + skladnik2 + "=" + wynik3);
let wynik4 = skladnik1 * skladnik2;
document.write(skladnik1 + "*" + skladnik2 + "=" + wynik4);