let kolory = [];
for(let i=0; i<=6; i++){
    kolory[i] = (1e1)+i+1
}
for(let j=0; j<6; j++){
    console.log(kolory[j])
}

