// przykład 3.18
var a = 10;
var b='10';
if(a==b)
{
    document.write("Liczby są równe.");
}
else
{
    document.write("Liczby nie są równe.");
}