// Przykład 3.40
isFinite(Infinity);
isFinite(-Infinity);
isFinite(67);
isFinite(2E12);