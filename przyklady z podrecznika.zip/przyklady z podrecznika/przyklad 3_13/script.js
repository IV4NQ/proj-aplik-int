// Przykład 3_13
var k = true;