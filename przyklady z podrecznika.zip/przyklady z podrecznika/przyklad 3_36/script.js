// przyklad 3.36
parseInt("123");
parseInt("123AB", 16);
parseInt("123", 8);
parseInt("123AB", 8);
parseInt("0377");
parseInt("0x373");