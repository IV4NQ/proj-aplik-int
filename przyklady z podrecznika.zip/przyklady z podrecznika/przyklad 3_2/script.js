// Przykład 3.2
document.write("Napisz program w języku JavaScript");