//Przykład 3.15
var liczby = [10, 23, 57, 94, 32];